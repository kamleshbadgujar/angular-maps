import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { AgmCoreModule } from '@agm/core';
import { PanelComponent } from './panel/panel.component';
import { MapComponent } from './map/map.component'
import { LocationsService } from './locations.service';
import { MapsService } from './maps.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    PanelComponent,
    MapComponent
  ],
  imports: [
    BrowserModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyC7jwHPbCC5h4ME-68buOhv19bNMOMbgiQ',
      libraries: ['places', 'geometry']
    }),
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [LocationsService, MapsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
