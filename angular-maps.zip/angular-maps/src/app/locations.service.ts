import { Injectable } from '@angular/core';
import { Marker } from '../models';

@Injectable()
export class LocationsService {

  // @Todo: replace markers by an API
  markers: Marker[] = [
    {
      lat: 19.21639331989832,
      lng: 73.14141329244063,
      title: 'Ayur Hospital',
      icon: 'src/assets/air-balloon.png',
      draggable: false,
      street: 'Chinchpada Gaon',
      city: 'Toronto',
      state: 'ON',
      postalcode: '421306',
      email: 'test@example.com',
      phone: '111-111-1111',
      website: 'http://example.com',
      detail: 'InfoWindow content'
    },
    {
      lat: 19.207132581686707,
      lng: 73.10590556655802,
      title: 'Orthoved Ayurvedic Hospital',
      icon: 'src/assets/air-balloon.png',
      draggable: false,
      street: 'Chinchpada Gaont',
      city: 'Toronto',
      state: 'ON',
      postalcode: '421306',
      email: 'test@example.com',
      phone: '111-111-1111',
      website: 'http://example.com',
      detail: 'InfoWindow content'
    },
    {
      lat: 19.22252428024008,
      lng: 73.10299731472382,
      title: 'Shree Ayurveda Chikitsalaya & Panchakarma Kendra',
      icon: 'src/assets/air-balloon.png',
      draggable: false,
      street: '2222 McKinney Ave Suite 120',
      city: 'Toronto',
      state: 'ON',
      postalcode: '421306',
      email: 'test@example.com',
      phone: '111-111-1111',
      website: 'http://example.com',
      detail: 'InfoWindow content'
    }
  ];

  constructor() { }

  getMarkers() {
    return this.markers;
  }

}
